window.CONFIG = {
  API_URL: "วาง_WEB_APP_URL_จาก_APPS_SCRIPT_ที่นี่",
  SHOP: { name: "บ้านผึ้งหวาน", phone: "081-234-5678", address: "99 ม.1 ต.แม่ริม อ.แม่ริม จ.เชียงใหม่ 50180" },
  SHIPPING: { fee: 50, freeOver: 600 },
  BANK: "ธนาคารกสิกรไทย 123-4-56789-0 ชื่อบัญชี บ้านผึ้งหวาน",
  PRODUCTS: [
    { sku: "HNY-WF-500", name: "น้ำผึ้งดอกไม้ป่า", size: "500 กรัม", weight: 650, price: 289, img: "images/wildflower.svg",
      desc: "เก็บจากรังผึ้งในป่าเชิงดอย รสหวานกลมกล่อม กลิ่นดอกไม้หลายชนิด" },
    { sku: "HNY-LG-300", name: "น้ำผึ้งดอกลำไย", size: "300 กรัม", weight: 420, price: 219, img: "images/longan.svg",
      desc: "สีเข้ม กลิ่นหอมเฉพาะตัว เหมาะกับชา โยเกิร์ต และขนมปัง" },
    { sku: "HNY-CB-250", name: "น้ำผึ้งรวงสด", size: "250 กรัม", weight: 380, price: 249, img: "images/comb.svg",
      desc: "รวงผึ้งทั้งชิ้นจากรังจริง กินได้ทั้งน้ำผึ้งและขี้ผึ้ง" }
  ]
};
