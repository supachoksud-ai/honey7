# บ้านผึ้งหวาน – Landing page ขายน้ำผึ้ง

โครงสร้าง: `index.html` (หน้าขาย) · `admin.html` (หยิบ/แพ็ค/ปะหน้า) · `config.js` (สินค้า, ที่อยู่ร้าน, URL ของ Sheet) · `Code.gs` (Google Apps Script) · `images/` (รูปสินค้า)

## 1) ตั้งค่า Google Sheet
1. สร้าง Google Sheet ใหม่ → เมนู **Extensions > Apps Script**
2. วางโค้ดจาก `Code.gs` แล้วแก้ `ADMIN_KEY` เป็นรหัสลับของคุณ (และราคา/SKU ให้ตรงกับ `config.js`)
3. **Deploy > New deployment > Web app** · Execute as: **Me** · Who has access: **Anyone** → Deploy แล้วอนุญาตสิทธิ์
4. คัดลอก Web app URL ไปใส่ `API_URL` ใน `config.js`
5. ชีต `Orders` จะถูกสร้างอัตโนมัติเมื่อมีออเดอร์แรก (ทุกครั้งที่แก้ Code.gs ต้อง Deploy > Manage deployments > New version)

## 2) รูปสินค้า
ใส่ไฟล์รูปใน `images/` แล้วแก้ชื่อไฟล์ใน `config.js` (ตอนนี้เป็น SVG ตัวอย่าง)

## 3) ขึ้น GitHub + Vercel
```
git init && git add . && git commit -m "honey shop"
git branch -M main
git remote add origin https://github.com/<user>/<repo>.git && git push -u origin main
```
Vercel → **Add New Project** → เลือก repo → Framework: **Other** → Deploy (ไม่ต้อง build)
โดเมนของตัวเอง: Project > Settings > Domains

## 4) ใช้งานหลังบ้าน
เปิด `https://โดเมนของคุณ/admin` → ใส่ `ADMIN_KEY` → เลือกออเดอร์
- **ใบหยิบสินค้า**: รวมจำนวนแต่ละ SKU ของออเดอร์ที่เลือก
- **ใบปะหน้า+ใบแพ็ค**: ขนาด 100×150 มม. (เลือกขนาดกระดาษในหน้าต่างพิมพ์) มีผู้ส่ง ผู้รับ รายการสินค้า น้ำหนัก
- **แพ็คแล้ว / ส่งแล้ว+เลขพัสดุ**: อัปเดตกลับไปที่ Sheet

หมายเหตุ: ออเดอร์ใหม่มีสถานะ "รอชำระ/รอแพ็ค" ให้แก้เป็นอย่างอื่นใน Sheet ได้หากต้องการแยกขั้นตอนตรวจสลิป
