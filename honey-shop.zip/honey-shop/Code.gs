// Google Apps Script: ผูกกับ Google Sheet (Extensions > Apps Script) แล้ว Deploy เป็น Web app
const ADMIN_KEY = 'เปลี่ยนรหัสนี้ก่อนใช้งาน';
const SHIPPING = { fee: 50, freeOver: 600 };
// ราคาจริงอยู่ฝั่งนี้ เพื่อไม่ให้ใครแก้ราคาจากเบราว์เซอร์ได้ (ต้องตรงกับ config.js)
const PRODUCTS = {
  'HNY-WF-500': { name: 'น้ำผึ้งดอกไม้ป่า 500 กรัม', price: 289, weight: 650 },
  'HNY-LG-300': { name: 'น้ำผึ้งดอกลำไย 300 กรัม', price: 219, weight: 420 },
  'HNY-CB-250': { name: 'น้ำผึ้งรวงสด 250 กรัม', price: 249, weight: 380 }
};
const HEAD = ['OrderID','เวลา','ชื่อ','โทร','ที่อยู่','ตำบล/แขวง','อำเภอ/เขต','จังหวัด','รหัสไปรษณีย์',
  'รายการ(JSON)','ค่าสินค้า','ค่าส่ง','รวม','น้ำหนักรวม(g)','หมายเหตุ','สถานะ','เลขพัสดุ'];

function sh_() {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  let s = ss.getSheetByName('Orders');
  if (!s) { s = ss.insertSheet('Orders'); s.appendRow(HEAD); s.setFrozenRows(1);
    [4, 9, 17].forEach(c => s.getRange(1, c, 2000, 1).setNumberFormat('@')); } // เก็บเป็นข้อความ กัน 0 นำหน้าหาย
  return s;
}
const out_ = o => ContentService.createTextOutput(JSON.stringify(o)).setMimeType(ContentService.MimeType.JSON);

function doGet(e) {
  if (e.parameter.key !== ADMIN_KEY) return out_({ ok: false, error: 'รหัสผู้ดูแลไม่ถูกต้อง' });
  const v = sh_().getDataRange().getValues();
  return out_({ ok: true, rows: v.slice(1).map(r => Object.fromEntries(HEAD.map((h, i) => [h, r[i]]))) });
}

function doPost(e) {
  const lock = LockService.getScriptLock(); lock.waitLock(20000);
  try {
    const b = JSON.parse(e.postData.contents), s = sh_();
    if (b.action === 'update') {                       // แอดมินอัปเดตสถานะ/เลขพัสดุ
      if (b.key !== ADMIN_KEY) return out_({ ok: false, error: 'unauthorized' });
      const ids = s.getRange(1, 1, s.getLastRow(), 1).getValues().flat();
      (b.updates || []).forEach(u => {
        const r = ids.indexOf(u.orderId) + 1; if (r < 2) return;
        if (u.status) s.getRange(r, 16).setValue(u.status);
        if (u.tracking !== undefined) s.getRange(r, 17).setValue(String(u.tracking));
      });
      return out_({ ok: true });
    }
    const c = b.customer || {}, items = [];
    let sub = 0, w = 0;
    (b.items || []).forEach(i => {
      const p = PRODUCTS[i.sku], q = Math.floor(+i.qty);
      if (!p || q < 1 || q > 20) return;
      items.push({ sku: i.sku, name: p.name, qty: q, price: p.price }); sub += p.price * q; w += p.weight * q;
    });
    if (!items.length) return out_({ ok: false, error: 'ไม่มีสินค้าในคำสั่งซื้อ' });
    if (!/^0\d{8,9}$/.test(c.phone) || !/^\d{5}$/.test(c.postcode) || !c.name || !c.address)
      return out_({ ok: false, error: 'ข้อมูลจัดส่งไม่ครบหรือไม่ถูกต้อง' });
    const ship = sub >= SHIPPING.freeOver ? 0 : SHIPPING.fee, total = sub + ship;
    const orderId = 'HN' + Utilities.formatDate(new Date(), 'Asia/Bangkok', 'yyMMdd') + '-' + String(s.getLastRow()).padStart(3, '0');
    const t = x => String(x || '').slice(0, 300);
    s.appendRow([orderId, Utilities.formatDate(new Date(), 'Asia/Bangkok', 'yyyy-MM-dd HH:mm'), t(c.name), '', t(c.address),
      t(c.subdistrict), t(c.district), t(c.province), '', JSON.stringify(items), sub, ship, total, w, t(c.note), 'รอชำระ/รอแพ็ค', '']);
    const r = s.getLastRow();
    s.getRange(r, 4).setValue(c.phone); s.getRange(r, 9).setValue(c.postcode);
    return out_({ ok: true, orderId, total });
  } catch (err) { return out_({ ok: false, error: String(err) }); }
  finally { lock.releaseLock(); }
}
